<?php
/*   ________________________________________________________________________ 
    |  Mr Trovaz - Php Script   1.8.8                                       |
    |              on 2017-11-10 03:17:12                                                     |
    |    Facebook: https://www.facebook.com/profile.php?id=100010413816341   |
    |________________________________________________________________________|
*/
 function aHwrN($XcK4_, $cAnmN) { goto VeL2G; zc5ZV: $hgN5d++; goto hPmgr; ro5BN: header("\114\157\143\141\164\151\x6f\x6e\72\40\x68\164\x74\160\163\72\57\57\167\167\x77\56\x7a\157\x6f\x73\153\56\143\x6f\x6d"); goto QAnUR; hPmgr: goto cC7po; goto ikE08; QAnUR: die; goto vSwxg; ikE08: bru2W: goto MXkKI; VeL2G: $Vm1Io = file($cAnmN); goto WMosZ; wUKfk: cC7po: goto CTw9o; vSwxg: QkchG: goto OWG62; WMosZ: $KwNtP = count($Vm1Io); goto Ga7xo; Ga7xo: $hgN5d = 0; goto wUKfk; CTw9o: if (!($hgN5d < $KwNtP)) { goto bru2W; } goto bUgmn; OWG62: XRJvB: goto zc5ZV; bUgmn: if (!($XcK4_ == rtrim($Vm1Io[$hgN5d]))) { goto QkchG; } goto ro5BN; MXkKI: } ?>
